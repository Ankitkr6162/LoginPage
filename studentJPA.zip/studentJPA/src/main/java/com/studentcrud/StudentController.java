package com.studentcrud;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;


@Controller
public class StudentController {
	
	@RequestMapping("registration")
	public String displayregistrationform(Model m)
	{
		StudentC s=new StudentC();
		m.addAttribute("stdreg",s);
		return "registrationform";
	}
	
	@RequestMapping("submitform")
	public String submitform(@ModelAttribute("stdreg") StudentC st)
	{
		EntityManagerFactory ef=Persistence.createEntityManagerFactory("puc");
		EntityManager em=ef.createEntityManager();
		em.getTransaction().begin();
		em.persist(st);
		em.getTransaction().commit();
		return "confirmation";
	}
	
	

}
