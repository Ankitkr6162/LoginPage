package com.studentcrud;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class StudentC {
	
	@Id
	private int sId;
	private String sName;
	private double sPer;
	private String sGender;
	
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public double getsPer() {
		return sPer;
	}
	public void setsPer(double sPer) {
		this.sPer = sPer;
	}
	public String getsGender() {
		return sGender;
	}
	public void setsGender(String sGender) {
		this.sGender = sGender;
	}
	
	
	
	

}
